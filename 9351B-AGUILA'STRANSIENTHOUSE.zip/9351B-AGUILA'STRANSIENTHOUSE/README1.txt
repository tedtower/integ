The absolute path of the text files are used as the path set in the creation of
File objects in the programs.